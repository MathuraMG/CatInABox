This folder is still being populated.
The 3d model it contains is what I used in the original book to cover the 8 pin IC holder that held the lights.

The lights plus the circuits will soon be available in this folder.
In case of anyone questions, please reach out to me at mmg542@nyu.edu

--Mathura
